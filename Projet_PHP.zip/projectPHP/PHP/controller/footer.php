<footer>
	Site créée par Quentin Dias et Victor Pavaday 
	<br/>	Nous contacter au : ***************
	<br/>	Adresse email : *****************

</footer>
</body>
</html>
