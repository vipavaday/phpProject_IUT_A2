<?php
    session_id("userSession");
    session_start();
    
    require_once $_SERVER['DOCUMENT_ROOT'].'/view/commonFunctions.php';
    outputEnTeteHTML5("Mon compte","UTF-8","/view/classes/style.css");
    echo '<a> Se déconnecter</a>';
    outputFinFichierHTML5();
?>

