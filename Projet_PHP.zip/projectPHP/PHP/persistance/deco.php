<?php
session_id("userSession");
session_start();
session_unset();
session_destroy();

require_once $_SERVER['DOCUMENT_ROOT'].'/view/commonFunctions.php';
outputEnTeteHTML5("Mon compte","UTF-8","/view/classes/style.css");
echo '<h2>Vous avez bien été déconnecté</h2>';
outputFinFichierHTML5();
?>

