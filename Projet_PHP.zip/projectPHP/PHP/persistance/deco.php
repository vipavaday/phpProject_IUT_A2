<?php
session_id("userSession");
session_destroy();

//require_once $_SERVER['DOCUMENT_ROOT'].'/view/commonFunctions.php';
//outputEnTeteHTML5("Mon compte","UTF-8","/view/classe/style.css");
//outputFinFichierHTML5();
?>

